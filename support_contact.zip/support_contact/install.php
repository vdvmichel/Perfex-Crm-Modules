<?php

defined('BASEPATH') or exit('No direct script access allowed');

add_option('support_contact', 'enable');
add_option('support_contact_viber', '+396946941040');
add_option('support_contact_whatsapp', '+396946941040');
add_option('support_contact_messenger_username', 'helpsupport');
add_option('support_contact_email_address', 'info@helpsupport.com');
add_option('aio_support_backend', '0');
add_option('aio_support_frontend', '0');