<?php
#  Version 1.0
$lang['support_contact'] = 'AIO Support Contact';
$lang['contact_text'] = 'contact';
$lang['messenger_text'] = 'Messenger';
$lang['whatsapp_text'] = 'WhatsApp';
$lang['viber_text'] = 'Viber';
$lang['email_text'] = 'Email us';
$lang['support_msgs'] = '"Heyo!","We are around to help!","Feel free to press the contact button"';