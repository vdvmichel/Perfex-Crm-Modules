<div class="col-md-4">
  <div class="panel_s">
    <div class="panel-body">
      <div id="container_task"></div>
    </div>
  </div>
</div>
<div class="col-md-4">
  <div class="panel_s">
    <div class="panel-body">
      <div id="container_time" class="container_time"></div>
    </div>
  </div>
</div>
<div class="col-md-4">
  <div class="panel_s">
    <div class="panel-body">
      <div id="container_priority" class="container_priority"></div>
    </div>
  </div>
</div>