<label class="control-label">
     <div class="calendar-cpicker cpicker cpicker-big br_customer" data-toggle="tooltip" title="<?php echo _l('client'); ?>"></div>
     <div class="calendar-cpicker cpicker cpicker-big br_project" data-toggle="tooltip" title="<?php echo _l('project'); ?>"></div>
     <div class="calendar-cpicker cpicker cpicker-big br_expense" data-toggle="tooltip" title="<?php echo _l('expense'); ?>"></div>
     <div class="calendar-cpicker cpicker cpicker-big br_ticket" data-toggle="tooltip" title="<?php echo _l('ticket'); ?>"></div>
     <div class="calendar-cpicker cpicker cpicker-big br_lead" data-toggle="tooltip" title="<?php echo _l('lead'); ?>"></div>
     <div class="calendar-cpicker cpicker cpicker-big br_contract" data-toggle="tooltip" title="<?php echo _l('contract'); ?>"></div>
     <div class="calendar-cpicker cpicker cpicker-big br_invoice" data-toggle="tooltip" title="<?php echo _l('invoice'); ?>"></div>
     <div class="calendar-cpicker cpicker cpicker-big br_estimate" data-toggle="tooltip" title="<?php echo _l('estimate'); ?>"></div>
     <div class="calendar-cpicker cpicker cpicker-big br_proposal" data-toggle="tooltip" title="<?php echo _l('proposal'); ?>"></div>
</label>

<svg id="timeline"></svg>