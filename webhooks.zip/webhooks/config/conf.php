<?php

defined('BASEPATH') || exit('No direct script access allowed');

$config['product_item_id'] = '25278359';
