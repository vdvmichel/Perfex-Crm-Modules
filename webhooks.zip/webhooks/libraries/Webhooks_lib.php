<?php

declare(strict_types=1);

defined('BASEPATH') || exit('No direct script access allowed');

    class Webhooks_lib
    {
        public function __construct()
        {
        }
    }
