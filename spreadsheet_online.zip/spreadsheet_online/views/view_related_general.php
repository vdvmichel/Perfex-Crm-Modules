<div class="row">
	<hr>
	<div class="col-sm-12">
		<table id="spreadsheet-advanced">
			<caption>

			</caption>
			<thead>
				<tr>
					<th><?php echo _l('name') ?></th>
					<th><?php echo _l('kind') ?></th>
					<th><?php echo _l('related_to') ?></th>
				</tr>
			</thead>
			<?php echo html_entity_decode($folder_my_tree); ?>
		</table>
	</div>
</div>