<?php
$lang['settings_group_telegram_notification_enable']                              = 'Enable Telegram Notification';
$lang['settings_group_telegram_notification']                              = 'Telegram Notification';
$lang['settings_telegram_notification_token']                              = 'Telegram bot token';
$lang['settings_telegram_notification_channel_link']                       = 'Telegram Channel Link (for example "https://t.me/channelname")';