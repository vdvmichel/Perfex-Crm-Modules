<?php
defined('BASEPATH') or exit('No direct script access allowed');

add_option('telegram_notification_enabled', '');
add_option('telegram_notification_token', '');
add_option('telegram_notification_channel_link', '');