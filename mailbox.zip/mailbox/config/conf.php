<?php 
defined('BASEPATH') OR exit('No direct script access allowed');


$config['product_item_id'] = "25308081";

