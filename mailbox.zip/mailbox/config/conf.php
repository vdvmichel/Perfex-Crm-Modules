<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$config['mailbox_product_item_id'] = "25308081";
$config["mailbox_product_token"] = "";