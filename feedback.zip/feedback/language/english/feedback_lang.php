<?php

# Version 1.0

$lang['create_feedback_request']   	='Create Feedback Request'; 
$lang['project_feedbacks']      	='Project Feedbacks'; 
$lang['projects_fd']				='Projects';    
$lang['provide_feedbacks']			='Provide Feedback';   
$lang['submit']						='Submit';       
$lang['overall_rating']				='Overall Rating';        
$lang['rate_coding']				='How do you rate our coding?'; 
$lang['communication']				='Would you would rate our communication?';
$lang['services']					='How do you rate our overall services?';
$lang['recommendation']				='Would you recommend us to others?';
$lang['project_fd']					='Project'; 
$lang['review_comments']			='Review Comments';
$lang['select']						='Select';
$lang['excellent']					='Excellent';
$lang['very_good']					='Very Good';
$lang['good']						='Good';
$lang['fair']						='Fair';
$lang['bad']						='Bad';
$lang['communication_comments']		='Comments';
$lang['request_for_feedback']		='Request For Feedback';

// Menu
$lang['feedback']					='Feedback';
$lang['feedback_received']			='Feedback Received';
$lang['send_request']				='Send Request';
$lang['customer_feedback']			='Feedback request';                                      
$lang['submit_feedback']			='Feedback send';   

// Alerts
$lang['feedback_already_exists']	='Feedback request already exist';
$lang['feedback_added_successfully']	='Feedback added!';      

                                      