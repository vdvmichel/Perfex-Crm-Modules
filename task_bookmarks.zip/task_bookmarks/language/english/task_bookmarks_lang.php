<?php

$lang['task_bookmarks_name'] = 'Task bookmark name';
$lang['task_bookmarks'] = 'Task bookmarks';
$lang['new_task_bookmarks'] = 'New task bookmark';
$lang['view_task_bookmarks'] = 'View task bookmark';
$lang['edit_task_bookmarks'] = 'Edit task bookmark';
$lang['delete_task_bookmarks'] = 'Delete bookmark';
$lang['list_task_bookmarks'] = 'List task bookmarks';
$lang['no_task_bookmarks'] = 'No task bookmarks';
$lang['remove_dashboard'] = 'Remove from dashboard';
$lang['milestones_name'] = 'Milestone Name';
$lang['add_dashboard'] = 'Add to Dashboard';
$lang['utilities_menu_icon'] = 'Icon';
$lang['added_to_dashboard'] = 'Already added to dashboard. If you want to remove it, you can do it from Dashboard.';
$lang['task_filter_name'] = 'Bookmark Name';
$lang['creator'] = 'Bookmark creator';