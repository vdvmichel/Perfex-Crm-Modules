        // "use strict"
        
        // $(".servicesForm").submit(function(e) {
        //     $('#hidden-field').empty();
        //     e.preventDefault();
        //     $.each($(this).find(':input'), function(index, field) {
        //         if (index > 0 && index < 3)
        //             $('#hidden-field').append($(field).addClass('hidden'));
        //     });

        //     $('#subscriptionProduct').modal({
        //         show: true
        //     });
        // });
