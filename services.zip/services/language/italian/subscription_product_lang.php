<?php
$lang['stripe_new_product'] = 'nuovo prodotto';
$lang['plan'] = 'piano';
$lang['product'] = 'prodotto';
$lang['services'] = 'Servizi';
$lang['stripe_products'] = "prodotti in abbonamento";
$lang['related_to'] = "Disponibile per (non lasciare nulla selezionato per tutti i clienti)";
$lang['customer_group'] = "gruppo cliente";
