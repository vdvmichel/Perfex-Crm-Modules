<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$config['extended_email_product_item_id'] = "39695653";
$config["extended_email_product_token"] = "";
