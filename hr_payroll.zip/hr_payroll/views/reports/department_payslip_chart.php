<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="relative department_payslip_chart">
   <div id="department_payslip_chart" class="reports" ></div>
</div>