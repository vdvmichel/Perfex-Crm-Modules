<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div id="insurance_cost_summary_report" class="hide reports">
	<table class="table table-insurance_cost_summary_report scroll-responsive">
		<thead>
			<tr>
				
				<th><?php echo _l('department_name'); ?></th>
				
				<th><?php echo _l('ps_total_insurance'); ?></th>

			</tr>
		</thead>
		<tbody></tbody>
		<tfoot>
		
			<td></td>
			<td></td>

		</tfoot>
		
	</table>
</div>
