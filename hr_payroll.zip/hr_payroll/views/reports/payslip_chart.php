
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="payslip_chart hide" >
   <div id="payslip_chart" class="reports" ></div>
</div>