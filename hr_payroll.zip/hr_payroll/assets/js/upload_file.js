(function(){
$('#file-link').on('click', function(e) {
	"use strict";

	e.preventDefault();
	$('#Luckyexcel-demo-file').trigger('click');
});

})(jQuery);
