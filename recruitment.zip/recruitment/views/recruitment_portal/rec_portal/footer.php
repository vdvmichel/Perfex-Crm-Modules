<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="pusher"></div>
<footer class="navbar-fixed-bottom footer">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<span class="copyright-footer"><?php echo date('Y'); ?> <?php echo _l('clients_copyright', get_option('companyname')); ?></span>
			</div>
		</div>
	</div>
</footer>

