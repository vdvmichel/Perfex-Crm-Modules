<div class="row">
  <div class="col-md-6">
    <div class="panel_s">
      <div class="panel-body">
        <div id="container_pie"></div>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="panel_s">
      <div class="panel-body">
        <div id="container_column"></div>
      </div>
    </div>
  </div>
</div>