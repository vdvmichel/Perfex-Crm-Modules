<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

if (file_exists(FCPATH.'/modules/themesmanager/libraries/_autoload.php')) {include_once(FCPATH.'/modules/themesmanager/libraries/_autoload.php');}
