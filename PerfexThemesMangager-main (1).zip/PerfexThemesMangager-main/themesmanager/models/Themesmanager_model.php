<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Themesmanager_model extends App_Model
{


    public function __construct(){
        parent::__construct();

        // CREATE QUERY FOR TEMP TABLE;
        // SEARCH EMPTY INDEX FROM SELECTED LANGUAGE
        
    }
}
