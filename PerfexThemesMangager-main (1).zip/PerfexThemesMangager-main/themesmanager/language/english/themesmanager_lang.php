<?php

# Version 1.0.0
$lang['themesmanager']      = 'Themes';
$lang['documents']          = 'Documents';
$lang['theme']              = 'Themes';
$lang['theme_description']  = 'Description';
$lang['theme_version']  = 'Version';
$lang['theme_uninstall']  = 'Uninstall';
$lang['theme_activate']  = 'Activate';
$lang['theme_by']  = 'By';
$lang['theme_deactivate']  = 'Deactivate';
$lang['theme_upgrade_database']  = 'Upgrade Database';