<?php

# Version 1.0.0
$lang['themesmanager']      = 'Giao diện';
$lang['documents']          = 'Tài liệu';
$lang['theme']              = 'Giao diện';
$lang['theme_description']  = 'Mô tả';
$lang['theme_version']      = 'Phiên bản';
$lang['theme_uninstall']    = 'Xóa bỏ';
$lang['theme_activate']     = 'Kích hoạt';
$lang['theme_by']           = 'Bởi';
$lang['theme_deactivate']   = 'Ngừng kích hoạt';
$lang['theme_upgrade_database']  = 'Nâng cấp dữ liệu';