<?php

defined('BASEPATH') or exit('No direct script access allowed');

return [ 'lead_manager/sms_control/incoming_sms_status_webhook' ];