<?php
$lang['settings_paymentmethod_country'] = 'Payment country';