# Elite Custom JS and CSS
Allows admin to add multiple custom JavaScript and CSS in admin area, client area and both with beautiful editor
