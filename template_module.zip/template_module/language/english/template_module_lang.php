<?php

# Version 2.3.0

$lang['auto_backup_options_updated']     = 'Auto backup options updated';