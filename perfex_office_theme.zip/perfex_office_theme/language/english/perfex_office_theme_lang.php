<?php
defined('BASEPATH') or exit('No direct script access allowed');
$lang['settings_yes'] = 'Yes';
$lang['settings_no'] = 'No';
$lang['perfex_office_theme_settings_first'] = 'Office Theme';
$lang['perfex_office_theme_settings'] = 'Enable customer area office theme support';
