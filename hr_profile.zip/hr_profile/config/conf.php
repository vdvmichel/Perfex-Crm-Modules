<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
$config['product_item_id'] = "31317939";
$config['gtss_env_key'] = "BnmJlriqoBYMSbU1cNJJn9eDle8QG4qu";

