(function() {
    window.KITYMINDER_CONFIG = {
        
        readOnly: false,

        defaultTemplate: 'default',

        defaultTheme: 'fresh-blue',

        maxUndoCount: 20,

        lang: 'en-us',
        
        maxImageWidth: 200,
        maxImageHeight: 200,

        autoSave: 2
    };
})();