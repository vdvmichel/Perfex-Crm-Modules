<li role="presentation" class="tab-separator">
    <a href="#pro_attachment" aria-controls="pro_attachment" role="tab" data-toggle="tab">
     <?php echo _l('attachment'); ?>
     </a>
</li>  