<div class="tab-pane" id="briefing">
    <label>Quem é e o que faz a empresa?</label>
    <textarea name="question_1" rows="5" cols="50"></textarea>

    <label>Quais os principais produtos da empresa?</label>
    <textarea name="question_2" rows="5" cols="50"></textarea>

    <label>Quem são os clientes?</label>
    <textarea name="question_3" rows="5" cols="50"></textarea>

    <label>Para onde a empresa vai?</label>
    <textarea name="question_4" rows="5" cols="50"></textarea>

    <label>Temos em mente alguma grande mudança para os próximos meses (período do planejamento)?</label>
    <textarea name="question_5" rows="5" cols="50"></textarea>

    <label>Qual a próxima grande novidade da empresa?</label>
    <textarea name="question_6" rows="5" cols="50"></textarea>

    <label>Temos em mente algum novo canal para explorar em um futuro próximo?</label>
    <textarea name="question_7" rows="5" cols="50"></textarea>

    <label>Existe algo que vocês sempre quiseram executar e nunca executaram?</label>
    <textarea name="question_8" rows="5" cols="50"></textarea>

    <label>Onde imaginamos a empresa ao fim de 2022?</label>
    <textarea name="question_9" rows="5" cols="50"></textarea>

    <label>Como funcionam as estratégias de marketing hoje? Quem são os envolvidos?</label>
    <textarea name="question_10" rows="5" cols="50"></textarea>

    <label>De tudo que vocês já fizeram até hoje em marketing, qual ação vocês consideram que melhor funcionou?</label>
    <textarea name="question_11" rows="5" cols="50"></textarea>

    <label>Vocês já executaram alguma ação que foi um fracasso? Como foi a experiência?</label>
    <textarea name="question_12" rows="5" cols="50"></textarea>

    <label>Qual a principal origem de novos clientes?</label>
    <textarea name="question_13" rows="5" cols="50"></textarea>

    <label>Como funciona o processo comercial?</label>
    <textarea name="question_14" rows="5" cols="50"></textarea>

    <label>Vocês trabalham com inbound? Quais as estratégias adotadas?</label>
    <textarea name="question_15" rows="5" cols="50"></textarea>

    <label>Qual a relação que vocês têm com influenciadores?</label>
    <textarea name="question_16" rows="5" cols="50"></textarea>

    <label>Quem são os responsáveis pela produção de conteúdo hoje na empresa?</label>
    <textarea name="question_17" rows="5" cols="50"></textarea>

    <label>Que tipo de conteúdo é mais confortável para vocês produzirem?</label>
    <textarea name="question_18" rows="5" cols="50"></textarea>

    <label>Quais ferramentas vocês têm hoje para auxiliar no marketing? (BI, SEMRush, RD, Hotjar, UbberSuggest...)</label>
    <textarea name="question_19" rows="5" cols="50"></textarea>

    <label>Vocês já fizeram um planejamento anual de marketing antes? Como foi a experiência?</label>
    <textarea name="question_20" rows="5" cols="50"></textarea>
</div>
