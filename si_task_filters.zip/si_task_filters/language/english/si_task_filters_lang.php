<?php

# Version 1.0.0
$lang['custom_reports']      = 'SI Task Filters';
$lang['tasks_filter']        = 'Task Filters';
$lang['tasks_filter_templates']      = 'Task Filter Templates';
$lang['task_completed_date'] = 'Completed Date';
$lang['task_filter_by_date'] = 'Filter By Date';
$lang['task_related_to_and_name'] = 'Related to and Task Name';
$lang['task_name_and_related_to'] = 'Task Name and Related to';
$lang['filter_task_name'] = 'Task Name';
$lang['save_filter_template'] = 'Select Checked to Save Filter Template';
$lang['filter_template_name'] = 'Save as Filter Template (Add Filter Name here)';
$lang['no_filter_template'] = 'No Filter Templates Saved';
$lang['filter_templates'] = 'List of Filter Templates';
$lang['filter_name'] = 'Filter Name';
$lang['delete_confirm']='Are you sure you want to Delete this Filter Template?';
$lang['add_task_filter']='Add Task Filter';
$lang['hide_export_columns']='Hide  Export Columns';
$lang['si_apply_filter']='Apply Filter';
