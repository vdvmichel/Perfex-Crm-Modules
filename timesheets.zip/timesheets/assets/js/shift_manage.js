(function(){
	"use strict";
	initDataTable('.table-shift', admin_url + 'timesheets/shift_table', false, false, [], [5, 'desc']);
})(jQuery);
