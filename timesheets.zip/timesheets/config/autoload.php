<?php

defined('BASEPATH') or exit('No direct script access allowed');

$autoload['libraries'] = [
  'Format', 'app_tabs', 'app_object_cache', 'form_validation', 'mails/App_mail_template', 'merge_fields/app_merge_fields', 'Authorization_token'
];