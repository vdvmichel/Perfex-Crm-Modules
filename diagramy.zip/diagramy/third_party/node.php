<?php 
	defined('REG_PROD_POINT') or define('REG_PROD_POINT', 'http://envato.toofasthost.com/api/register');
	defined('VAL_PROD_POINT') or define('VAL_PROD_POINT', 'http://envato.toofasthost.com/api/validate');
?>