<?php

defined('BASEPATH') or exit('No direct script access allowed');

add_option('whatsapp_chat', 'enable');
add_option('whatsapp_chat_admin_area', '');
add_option('whatsapp_chat_clients_area', '');
add_option('whatsapp_chat_clients_and_admin_area', '');