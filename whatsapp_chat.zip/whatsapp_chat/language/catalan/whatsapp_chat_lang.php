<?php
#  Version 1.0
$lang['whatsapp_chat'] = 'WhatsApp Chat';

