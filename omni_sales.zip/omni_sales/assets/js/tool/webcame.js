(function(){
  "use strict";

})(jQuery);

