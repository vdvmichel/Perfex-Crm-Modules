(function(){
  "use strict";
  $('.exit_calculator').click(function(){
     $('#calculator').fadeOut(500);
  });
})(jQuery);

