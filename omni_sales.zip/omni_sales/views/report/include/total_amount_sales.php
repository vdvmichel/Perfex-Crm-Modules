<center><h4 class="chart_title"></h4></center>
<br>
<hr><br>
<figure class="highcharts-figure">
  <div id="container_total" class="hide"></div>
  <p class="highcharts-description">
  </p>
</figure>